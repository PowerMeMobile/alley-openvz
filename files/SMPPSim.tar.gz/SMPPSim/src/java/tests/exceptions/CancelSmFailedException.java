/*
 * Copyright (c) 2004
 * Martin Woolley
 * All rights reserved.
 *
 */
package tests.exceptions;

public class CancelSmFailedException extends Exception {
	public CancelSmFailedException() {
		super();
	}

}
